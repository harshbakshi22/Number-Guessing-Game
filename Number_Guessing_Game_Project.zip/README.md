
# Number Guessing Game

A simple Python command-line game where the user tries to guess a randomly generated number between 1 and 100.

## Features
- Random number generation
- User-friendly prompts
- Tracks number of attempts

## How to Run
1. Install Python (if not already installed)
2. Run the script using:
   ```bash
   python number_guessing_game.py
   ```

## Author
Harshvardhan Bakshi  
B.Tech CSE | Shri Ram Institute of Technology, Jabalpur
